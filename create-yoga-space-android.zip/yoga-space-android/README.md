# Create Yoga Space – Android (Google Play) project

A native Android wrapper (WebView) around the Create Yoga Space web app in `app/src/main/assets/index.html`.
Works fully offline. Package id: `com.strikebacktech.createyogaspace` (permanent once uploaded to Play - change it in
`app/build.gradle` and the Java folder name *before* the first upload if you want a different one).
minSdk 29 (Android 10), targetSdk 36 (Google Play requires 36+ for new apps from Aug 31, 2026).

## 1. Build the .aab in the cloud (easiest, nothing to install)
1. Create an empty GitHub repo and push the contents of this folder to the `main` branch.
2. Create your upload key once (needs Java): `./make-keystore.sh`. **Back up `upload-keystore.jks` and the passwords.**
3. In the repo go to Settings > Secrets and variables > Actions and add:
   `KEYSTORE_B64` (contents of `upload-keystore.b64.txt`), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (= `upload`), `KEY_PASSWORD`.
4. Actions tab > "Build Play Store AAB" > Run workflow. Download the `create-yoga-space-aab` artifact: that is your signed `app-release.aab`.
   (Without the secrets the workflow still builds, but the bundle is unsigned and Play will reject it.)

## 2. Or build locally
Open this folder in Android Studio and use Build > Generate Signed App Bundle, or:
```
KEYSTORE_PATH=/path/upload-keystore.jks KEYSTORE_PASSWORD=... KEY_ALIAS=upload KEY_PASSWORD=... ./gradlew :app:bundleRelease
```
Output: `app/build/outputs/bundle/release/app-release.aab`

## 3. Upload to Google Play
1. Play Console > Create app > keep **Play App Signing** on, then upload the .aab to Internal testing first.
2. Store listing: text in `play-store/PLAY_STORE_LISTING.md`, icon `play-store/icon-512.png`,
   feature graphic `play-store/feature-graphic-1024x500.png`, phone screenshots in `play-store/screenshots/`.
3. Privacy policy: host `play-store/PRIVACY_POLICY.md` as a web page and paste the URL in Play Console.
4. Complete App content: content rating, target audience, Data safety (answers in the listing file).
5. Every new upload needs a higher `versionCode` in `app/build.gradle`.
   New personal developer accounts may need a closed test with testers for a set number of days before production access - check the current rules in Play Console.

## Updating the app
Edit `app/src/main/assets/index.html` (or replace it with a newer copy of the web app, keeping the small
`AndroidBridge` script before `</body>`), raise `versionCode`, build again.

## Known limits (not yet tested on a device)
- Voice narration uses the phone's text-to-speech; the Sanskrit name uses a Hindi voice if installed.
- "Record video" saves WebM to Downloads through the `AndroidBridge`; recording depends on the device's WebView version.
- Shared flows, the forum and messages are on-device demos (selling flows has been removed). Before shipping real community features, user-generated content needs reporting and moderation. Add the INTERNET permission only when a server is connected.
