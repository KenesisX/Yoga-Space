# Privacy Policy – Create Yoga Space

Last updated: November 2026

Create Yoga Space ("the app") is developed by Jordan Kniffen.

**Data we collect:** None. The app has no accounts, no analytics, no ads and does not send any data over the internet.

**Data stored on your device:** Yoga flows you save, your display name/bio, avatar choices and volume settings are kept in the app's local storage on your device only. Videos you record are saved to your Downloads folder only if you choose to download them.

**Third parties:** Links in the app (yoga schools, resources, YouTube) open in your browser; those sites have their own privacy policies.

**Children:** The app is not directed to children under 13.

**Your choices:** Uninstalling the app or clearing its storage deletes all app data.

**Contact:** [add your contact email here]

This policy will be updated if the app begins to collect or transmit data (for example when a community server is added).
