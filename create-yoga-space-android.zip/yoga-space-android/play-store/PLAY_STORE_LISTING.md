# Play Store listing draft

**App name (30 max):** Create Yoga Space
**Short description (80 max):** Build yoga flows with an animated avatar, music and voice-guided poses.
**Category:** Health & Fitness  |  **Tags:** Yoga, Fitness, Meditation

## Full description
Create Yoga Space helps yoga instructors and fellow yogis design their own routines.

- Build a flow pose by pose and watch an animated avatar move through it
- Poses show the English and Sanskrit names, level, and the body areas they work (highlighted on the avatar)
- Tap a body part to read how that region benefits
- Pick a style: Vinyasa, Ashtanga (Mysore pace), Bikram, Iyengar or the Bikram Advanced series list
- "Suggest" tab: tell us your mood and where you are sore to get a routine
- Voice guide announces each pose in English and Sanskrit, with inhale/exhale cues and its own volume control
- Ambient music library or your own audio file
- Record your flow as a video
- 12 voice styles for the spoken guide, plus a master volume slider
- Learn Yoga library: benefits, styles, safety basics and trusted free resources

Educational use only. Not medical advice. Talk to a clinician before starting yoga with an injury or health condition.

Made by Jordan Kniffen, a Colorado developer and RYT200 yogi. Just breathe.

(Do not advertise shared flows, the forum or messaging until they run on a real server.)

## Data safety answers (current version)
- Data collected: none. Data shared: none. No accounts, no ads, no analytics, no network permission.
- Flows, profile name and settings are stored only on the device.
- Data is not encrypted in transit because nothing is transmitted. Users can delete data by clearing app storage / uninstalling.
Update these answers when you add a server.

## Other Play Console forms
- Content rating questionnaire: no violence, no user-to-user communication (yet), no purchases -> expected Everyone.
- Target audience: 18+ or 13+ (not designed for children).
- Ads: No.  Health apps declaration: choose the option for general wellness/fitness (not medical).
