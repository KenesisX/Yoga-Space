#!/usr/bin/env bash
# Creates your Play Store UPLOAD key. Run once, then BACK UP upload-keystore.jks and the passwords.
# Losing it means a support request to Google to reset the upload key.
set -e
keytool -genkeypair -v -keystore upload-keystore.jks -alias upload \
  -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 upload-keystore.jks > upload-keystore.b64.txt 2>/dev/null || base64 -i upload-keystore.jks > upload-keystore.b64.txt
echo
echo "Created upload-keystore.jks and upload-keystore.b64.txt"
echo "GitHub secrets to add: KEYSTORE_B64 (contents of the .b64.txt file), KEYSTORE_PASSWORD, KEY_ALIAS (= upload), KEY_PASSWORD"
